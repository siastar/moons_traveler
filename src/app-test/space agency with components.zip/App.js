import React, {Component} from "react"
import FormContainer from "./FormContainer.js"


function App (){
    return(
        <FormContainer/>
    )
}
export default App
