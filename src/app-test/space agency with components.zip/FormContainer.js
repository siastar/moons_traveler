import React, {Component} from 'react'
import FormComponent from './FormComponent.js'

class FormContainer extends Component {
    constructor() {
        super()
        this.state = {
            firstName: '',
            lastName: '',
            gender: '',
            destination: '',
            noBucatini: false,
            noRigatoni: false,
            noCarbonara: false           
        }
        this.changeHandler = this.changeHandler.bind(this) //changeHandler MUST be bound because alters the component's state
    }

    changeHandler(event){
        console.log('event.target:', event.target);
        const {value, name, type, checked} = event.target;

        type === 'checkbox' ? //(if condition) ? (is true - DoStuff) : (is false - DoOtherStuff)
        this.setState( {[name]: checked})
        : this.setState({[name]: value})                                 
    }
        
    render() {
        console.log('State: ', this.state);
        return (
            //calls the FormComponent module and passes it the changeHandler method and the this.state informations 
            <FormComponent
              changeHandler={this.changeHandler}
              data={this.state}
            />
        )
    }
}

export default FormContainer
